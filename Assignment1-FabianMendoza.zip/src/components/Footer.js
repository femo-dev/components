import '../css/index.css';

export default function Footer() {
  return (
    <footer className="footer">
      <p>&copy; 2025 My Components App. All rights reserved.</p>
    </footer>
  );
}